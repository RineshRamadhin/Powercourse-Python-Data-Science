COVID-19 Data Exploration
=========================

This notebook will load in a dataset of COVID-19 Community Mobility
report data from Google and explore it using Python and popular python
data science packages.

Imports
~~~~~~~

First let’s load in some packages.

.. code:: ipython3

    from __future__ import print_function, division
    import pandas as pd
    from pandas.plotting import scatter_matrix
    import numpy as np
    import scipy as sp
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    import seaborn as sns
    from IPython.core.display import HTML

.. code:: ipython3

    %matplotlib inline

Data ingest
~~~~~~~~~~~

Next let’s load in the dataset into a panda’s dataframe.

.. code:: ipython3

    df = pd.read_csv('../datasources/Global_Mobility_Report.csv', header=0, na_values = [''])
    countries = pd.read_csv('../datasources/country-and-continent-codes-list-csv.csv')


.. parsed-literal::

    /opt/conda/lib/python3.8/site-packages/IPython/core/interactiveshell.py:3155: DtypeWarning: Columns (4,5) have mixed types.Specify dtype option on import or set low_memory=False.
      has_raised = await self.run_ast_nodes(code_ast.body, cell_name,


.. code:: ipython3

    datetimes = ['date']
    df = df.set_index('country_region_code').join(countries.set_index('Two_Letter_Country_Code'))
    df[datetimes] = df[datetimes].apply(pd.to_datetime)

.. code:: ipython3

    sdf = df.sample(n = 50000)

Let’s explore!
~~~~~~~~~~~~~~

.. code:: ipython3

    df




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>country_region</th>
          <th>sub_region_1</th>
          <th>sub_region_2</th>
          <th>metro_area</th>
          <th>iso_3166_2_code</th>
          <th>census_fips_code</th>
          <th>place_id</th>
          <th>date</th>
          <th>retail_and_recreation_percent_change_from_baseline</th>
          <th>grocery_and_pharmacy_percent_change_from_baseline</th>
          <th>parks_percent_change_from_baseline</th>
          <th>transit_stations_percent_change_from_baseline</th>
          <th>workplaces_percent_change_from_baseline</th>
          <th>residential_percent_change_from_baseline</th>
          <th>Continent_Name</th>
          <th>Continent_Code</th>
          <th>Country_Name</th>
          <th>Three_Letter_Country_Code</th>
          <th>Country_Number</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>AE</th>
          <td>United Arab Emirates</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>ChIJvRKrsd9IXj4RpwoIwFYv0zM</td>
          <td>2020-02-15</td>
          <td>0.0</td>
          <td>4.0</td>
          <td>5.0</td>
          <td>0.0</td>
          <td>2.0</td>
          <td>1.0</td>
          <td>Asia</td>
          <td>AS</td>
          <td>United Arab Emirates</td>
          <td>ARE</td>
          <td>784.0</td>
        </tr>
        <tr>
          <th>AE</th>
          <td>United Arab Emirates</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>ChIJvRKrsd9IXj4RpwoIwFYv0zM</td>
          <td>2020-02-16</td>
          <td>1.0</td>
          <td>4.0</td>
          <td>4.0</td>
          <td>1.0</td>
          <td>2.0</td>
          <td>1.0</td>
          <td>Asia</td>
          <td>AS</td>
          <td>United Arab Emirates</td>
          <td>ARE</td>
          <td>784.0</td>
        </tr>
        <tr>
          <th>AE</th>
          <td>United Arab Emirates</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>ChIJvRKrsd9IXj4RpwoIwFYv0zM</td>
          <td>2020-02-17</td>
          <td>-1.0</td>
          <td>1.0</td>
          <td>5.0</td>
          <td>1.0</td>
          <td>2.0</td>
          <td>1.0</td>
          <td>Asia</td>
          <td>AS</td>
          <td>United Arab Emirates</td>
          <td>ARE</td>
          <td>784.0</td>
        </tr>
        <tr>
          <th>AE</th>
          <td>United Arab Emirates</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>ChIJvRKrsd9IXj4RpwoIwFYv0zM</td>
          <td>2020-02-18</td>
          <td>-2.0</td>
          <td>1.0</td>
          <td>5.0</td>
          <td>0.0</td>
          <td>2.0</td>
          <td>1.0</td>
          <td>Asia</td>
          <td>AS</td>
          <td>United Arab Emirates</td>
          <td>ARE</td>
          <td>784.0</td>
        </tr>
        <tr>
          <th>AE</th>
          <td>United Arab Emirates</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>ChIJvRKrsd9IXj4RpwoIwFYv0zM</td>
          <td>2020-02-19</td>
          <td>-2.0</td>
          <td>0.0</td>
          <td>4.0</td>
          <td>-1.0</td>
          <td>2.0</td>
          <td>1.0</td>
          <td>Asia</td>
          <td>AS</td>
          <td>United Arab Emirates</td>
          <td>ARE</td>
          <td>784.0</td>
        </tr>
        <tr>
          <th>...</th>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
        </tr>
        <tr>
          <th>NaN</th>
          <td>Namibia</td>
          <td>Otjozondjupa Region</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NA-OD</td>
          <td>NaN</td>
          <td>ChIJ_7SqpVK99hsRJoAG7f5HMeY</td>
          <td>2021-02-19</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>-14.0</td>
          <td>NaN</td>
          <td>Africa</td>
          <td>AF</td>
          <td>Namibia, Republic of</td>
          <td>NAM</td>
          <td>516.0</td>
        </tr>
        <tr>
          <th>NaN</th>
          <td>Namibia</td>
          <td>Otjozondjupa Region</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NA-OD</td>
          <td>NaN</td>
          <td>ChIJ_7SqpVK99hsRJoAG7f5HMeY</td>
          <td>2021-02-20</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>-17.0</td>
          <td>NaN</td>
          <td>Africa</td>
          <td>AF</td>
          <td>Namibia, Republic of</td>
          <td>NAM</td>
          <td>516.0</td>
        </tr>
        <tr>
          <th>NaN</th>
          <td>Namibia</td>
          <td>Zambezi Region</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NA-CA</td>
          <td>NaN</td>
          <td>ChIJ6ZWCJLviWRkR7vczZyMxxu4</td>
          <td>2020-04-13</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>-59.0</td>
          <td>NaN</td>
          <td>Africa</td>
          <td>AF</td>
          <td>Namibia, Republic of</td>
          <td>NAM</td>
          <td>516.0</td>
        </tr>
        <tr>
          <th>NaN</th>
          <td>Namibia</td>
          <td>Zambezi Region</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NA-CA</td>
          <td>NaN</td>
          <td>ChIJ6ZWCJLviWRkR7vczZyMxxu4</td>
          <td>2020-12-25</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>-75.0</td>
          <td>NaN</td>
          <td>Africa</td>
          <td>AF</td>
          <td>Namibia, Republic of</td>
          <td>NAM</td>
          <td>516.0</td>
        </tr>
        <tr>
          <th>NaN</th>
          <td>Namibia</td>
          <td>Zambezi Region</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NA-CA</td>
          <td>NaN</td>
          <td>ChIJ6ZWCJLviWRkR7vczZyMxxu4</td>
          <td>2021-01-01</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>-68.0</td>
          <td>NaN</td>
          <td>Africa</td>
          <td>AF</td>
          <td>Namibia, Republic of</td>
          <td>NAM</td>
          <td>516.0</td>
        </tr>
      </tbody>
    </table>
    <p>4567966 rows × 19 columns</p>
    </div>



.. code:: ipython3

    df.info()


.. parsed-literal::

    <class 'pandas.core.frame.DataFrame'>
    Index: 4567966 entries, AE to nan
    Data columns (total 19 columns):
     #   Column                                              Dtype         
    ---  ------                                              -----         
     0   country_region                                      object        
     1   sub_region_1                                        object        
     2   sub_region_2                                        object        
     3   metro_area                                          object        
     4   iso_3166_2_code                                     object        
     5   census_fips_code                                    float64       
     6   place_id                                            object        
     7   date                                                datetime64[ns]
     8   retail_and_recreation_percent_change_from_baseline  float64       
     9   grocery_and_pharmacy_percent_change_from_baseline   float64       
     10  parks_percent_change_from_baseline                  float64       
     11  transit_stations_percent_change_from_baseline       float64       
     12  workplaces_percent_change_from_baseline             float64       
     13  residential_percent_change_from_baseline            float64       
     14  Continent_Name                                      object        
     15  Continent_Code                                      object        
     16  Country_Name                                        object        
     17  Three_Letter_Country_Code                           object        
     18  Country_Number                                      float64       
    dtypes: datetime64[ns](1), float64(8), object(10)
    memory usage: 697.0+ MB


.. code:: ipython3

    df.describe()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>census_fips_code</th>
          <th>retail_and_recreation_percent_change_from_baseline</th>
          <th>grocery_and_pharmacy_percent_change_from_baseline</th>
          <th>parks_percent_change_from_baseline</th>
          <th>transit_stations_percent_change_from_baseline</th>
          <th>workplaces_percent_change_from_baseline</th>
          <th>residential_percent_change_from_baseline</th>
          <th>Country_Number</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>count</th>
          <td>928217.000000</td>
          <td>2.868086e+06</td>
          <td>2.774222e+06</td>
          <td>2.218548e+06</td>
          <td>2.315340e+06</td>
          <td>4.358439e+06</td>
          <td>2.664235e+06</td>
          <td>4.567966e+06</td>
        </tr>
        <tr>
          <th>mean</th>
          <td>30357.407207</td>
          <td>-2.389985e+01</td>
          <td>-2.756646e+00</td>
          <td>-9.899935e+00</td>
          <td>-2.736464e+01</td>
          <td>-2.003840e+01</td>
          <td>9.235258e+00</td>
          <td>4.858650e+02</td>
        </tr>
        <tr>
          <th>std</th>
          <td>15299.174033</td>
          <td>2.769400e+01</td>
          <td>2.500924e+01</td>
          <td>5.352491e+01</td>
          <td>3.013115e+01</td>
          <td>2.014508e+01</td>
          <td>7.832266e+00</td>
          <td>3.122592e+02</td>
        </tr>
        <tr>
          <th>min</th>
          <td>1001.000000</td>
          <td>-1.000000e+02</td>
          <td>-1.000000e+02</td>
          <td>-1.000000e+02</td>
          <td>-1.000000e+02</td>
          <td>-1.000000e+02</td>
          <td>-4.600000e+01</td>
          <td>4.000000e+00</td>
        </tr>
        <tr>
          <th>25%</th>
          <td>18105.000000</td>
          <td>-4.100000e+01</td>
          <td>-1.400000e+01</td>
          <td>-4.300000e+01</td>
          <td>-4.800000e+01</td>
          <td>-3.200000e+01</td>
          <td>4.000000e+00</td>
          <td>1.240000e+02</td>
        </tr>
        <tr>
          <th>50%</th>
          <td>29115.000000</td>
          <td>-2.000000e+01</td>
          <td>-2.000000e+00</td>
          <td>-1.700000e+01</td>
          <td>-2.800000e+01</td>
          <td>-1.900000e+01</td>
          <td>8.000000e+00</td>
          <td>5.660000e+02</td>
        </tr>
        <tr>
          <th>75%</th>
          <td>45051.000000</td>
          <td>-5.000000e+00</td>
          <td>9.000000e+00</td>
          <td>1.100000e+01</td>
          <td>-8.000000e+00</td>
          <td>-6.000000e+00</td>
          <td>1.300000e+01</td>
          <td>8.180000e+02</td>
        </tr>
        <tr>
          <th>max</th>
          <td>56045.000000</td>
          <td>5.450000e+02</td>
          <td>6.150000e+02</td>
          <td>1.206000e+03</td>
          <td>5.540000e+02</td>
          <td>2.600000e+02</td>
          <td>6.500000e+01</td>
          <td>8.940000e+02</td>
        </tr>
      </tbody>
    </table>
    </div>



Single column exploration
^^^^^^^^^^^^^^^^^^^^^^^^^

.. code:: ipython3

    single_df = sdf['retail_and_recreation_percent_change_from_baseline']

.. code:: ipython3

    sns.displot(single_df, rug=True) 




.. parsed-literal::

    <seaborn.axisgrid.FacetGrid at 0x7f43cc592f10>




.. image:: output_17_1.png


.. code:: ipython3

    single_df.plot.box()




.. parsed-literal::

    <AxesSubplot:>




.. image:: output_18_1.png


Multi column data exploration
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    multi_1_df = sdf['parks_percent_change_from_baseline']
    multi_2_df = sdf['transit_stations_percent_change_from_baseline']
    multi_df = sdf[['parks_percent_change_from_baseline', 'transit_stations_percent_change_from_baseline']].copy()

.. code:: ipython3

    multi_df.info()


.. parsed-literal::

    <class 'pandas.core.frame.DataFrame'>
    Index: 50000 entries, TR to BR
    Data columns (total 2 columns):
     #   Column                                         Non-Null Count  Dtype  
    ---  ------                                         --------------  -----  
     0   parks_percent_change_from_baseline             24232 non-null  float64
     1   transit_stations_percent_change_from_baseline  25245 non-null  float64
    dtypes: float64(2)
    memory usage: 1.1+ MB


.. code:: ipython3

    sns.jointplot(x=multi_1_df, y=multi_2_df, data=multi_df) 




.. parsed-literal::

    <seaborn.axisgrid.JointGrid at 0x7f436d7dbc40>




.. image:: output_22_1.png


And now for the entire dataset…
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    sns.pairplot(sdf, hue='Continent_Name', palette="husl") 


.. parsed-literal::

    /opt/conda/lib/python3.8/site-packages/seaborn/distributions.py:306: UserWarning: Dataset has 0 variance; skipping density estimate.
      warnings.warn(msg, UserWarning)
    /opt/conda/lib/python3.8/site-packages/seaborn/distributions.py:306: UserWarning: Dataset has 0 variance; skipping density estimate.
      warnings.warn(msg, UserWarning)
    /opt/conda/lib/python3.8/site-packages/seaborn/distributions.py:306: UserWarning: Dataset has 0 variance; skipping density estimate.
      warnings.warn(msg, UserWarning)
    /opt/conda/lib/python3.8/site-packages/seaborn/distributions.py:306: UserWarning: Dataset has 0 variance; skipping density estimate.
      warnings.warn(msg, UserWarning)
    /opt/conda/lib/python3.8/site-packages/seaborn/distributions.py:306: UserWarning: Dataset has 0 variance; skipping density estimate.
      warnings.warn(msg, UserWarning)




.. parsed-literal::

    <seaborn.axisgrid.PairGrid at 0x7f436d28bd00>




.. image:: output_24_2.png


.. code:: ipython3

    corr = sdf.corr()
    sns.heatmap(corr, xticklabels=True, yticklabels=True, cmap='RdBu') 




.. parsed-literal::

    <AxesSubplot:>




.. image:: output_25_1.png

